Extraxt the files open
Execute the files in Sphynx2\sphinx-4.x\Ajout\Sphinx\Locale\Eng-FRSphynx2emg
Copy the address of make bat example Ctrl C <C:\Users\Ghislain\Documents\Program\sphynx\sphinx-4.x\sphinx\templates\quickstart>
 execute the <cmd> command
change repertory on <cd..> two time enters
you arrive at the racine of the dd C:\
<Cd> Paste your adress Cotrl V <C:\Users\Ghislain\Documents\Program\sphynx2\sphinx-4.x\sphinx\templates\quickstart>
Reduce the C;\ of your Paste on let the Cd after the first C:`\ example <C:\ Cd Users\Ghislain\Documents\Program\sphynx2\sphinx-4.x\sphinx\templates\quickstart> Enter
<make.bat> Enter
<make value> Enter
<make value> Enter
exit
the value is changes if you want more space for your dd
the text to enter is  The text without the <> example <The text> must to be The text
Make that at all your disk on take care of the adress of the ware
I m alive Enjoy Yourself
Yoda Ghislain Pigeonneau