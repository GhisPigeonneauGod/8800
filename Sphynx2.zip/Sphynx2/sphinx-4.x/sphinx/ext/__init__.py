"""
    sphinx.ext
    ~~~~~~~~~~

    Contains Sphinx features not activated by default.

    :copyright: Copyright 2007-2022 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""
