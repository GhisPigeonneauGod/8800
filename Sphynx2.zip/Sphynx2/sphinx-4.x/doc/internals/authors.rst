:tocdepth: 2

.. _authors:

==============
Sphinx authors
==============

.. include:: ../../AUTHORS
